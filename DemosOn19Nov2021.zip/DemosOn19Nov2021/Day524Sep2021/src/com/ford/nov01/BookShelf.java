package com.ford.nov01;

public class BookShelf extends Furniture{

    int noOfShelves;
    public BookShelf() {
        super(); // Invoking base class constructor
    }

  /*  public BookShelf(int length,int width,int height ,int noOfShelves) {
        super(length,width,height);
        this.noOfShelves = noOfShelves;
    }

    public BookShelf(int noOfShelves) {
        this.noOfShelves = noOfShelves;
    }*/

    public void acceptBookShelfDetails()
    {
       /* System.out.println("Enter the Length ");
        length = scan1.nextInt();
        System.out.println("Enter the Width ");
        width = scan1.nextInt();
        System.out.println("Enter the Height ");
        height = scan1.nextInt(); */
        super.acceptFurnitureDetails();
        System.out.println("Enter the No Of Shelves");
        noOfShelves = scan1.nextInt();
    }
    public void displayBookShelfDetails()
    {
      /*  System.out.println("The Length is "+length);
        System.out.println("The Width is "+width);
        System.out.println("The Height is "+height);*/
        super.displayFurnitureDetails();
        System.out.println("The No Of Shelves is "+noOfShelves);
    }


}
