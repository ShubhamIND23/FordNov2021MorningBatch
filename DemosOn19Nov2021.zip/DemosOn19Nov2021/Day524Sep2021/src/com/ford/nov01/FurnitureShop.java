package com.ford.nov01;

public class FurnitureShop {

    public static void main(String[] args) {

        BookShelf shelf1 = new BookShelf();
        shelf1.displayBookShelfDetails();

      //  BookShelf shelf2 = new BookShelf(5,6,7,5);
        //shelf2.displayBookShelfDetails();
    /*    shelf1.acceptBookShelfDetails();
        shelf1.displayBookShelfDetails();

        Furniture furn1 = new Furniture();
        furn1.acceptFurnitureDetails();
        furn1.displayFurnitureDetails();*/
    }
}
