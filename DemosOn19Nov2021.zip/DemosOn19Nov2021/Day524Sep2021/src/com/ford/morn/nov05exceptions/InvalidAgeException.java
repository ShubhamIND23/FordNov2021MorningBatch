package com.ford.morn.nov05exceptions;

public class InvalidAgeException extends  Exception{
    String ageMessage;

    public InvalidAgeException(String ageMessage) {
        this.ageMessage = ageMessage;
    }

    @Override
    public String toString() {
        return "InvalidAgeException{" +
                "ageMessage='" + ageMessage + '\'' +
                '}';
    }
}
