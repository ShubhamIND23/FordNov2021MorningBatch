package com.ford.sep27;

public class SBIAccount implements InsuranceInterface,CreditCard{

    @Override
    public void calculateOutstanding() {
        System.out.println("Calculated Outstanding Amount...");
    }

    @Override
    public void calculateInterest() {
        System.out.println("Calculated Interest Amount...");
    }

    @Override
    public void closeAccount() {

        System.out.println("Closed Account...");
    }

    @Override
    public void createAccount() {

        System.out.println("Account Created...");
    }

    @Override
    public void calculatePremium() {
        System.out.println("Calculated Premium...");
    }

    @Override
    public void terminatePolicy() {
        System.out.println("Terminated Policy with number...");
    }

    @Override
    public void createPolicy() {
        System.out.println("Policy Created...");
    }

    @Override
    public void calculateTaxLiability() {
        System.out.println("Calculated Tax Liability....");
    }

    public static void main(String[] args) {
        SBIAccount myAccount = new SBIAccount();
        myAccount.createAccount();
        myAccount.calculateInterest();
        myAccount.calculatePremium();
        myAccount.calculateTaxLiability();
        myAccount.calculateOutstanding();
        myAccount.createPolicy();
        myAccount.closeAccount();
        myAccount.terminatePolicy();
    }
}
