package com.ford.sep27;

import java.util.Locale;

public class StringFunctionSample {

    public void checkStringBehaviour()
    {
        String str1 = "Hyderabad";
        String str2 = "Hyderabad";
      //  String str5 = "Chennai";
        System.out.println("str1.equals(str2)  : "+str1.equals(str2)); //true ? //
        System.out.println("str1 == str2  :"+(str1 == str2)); //true vishnu ? //false-- mounesh

        String str3 = new String("Hyderabad");
        String str4 = new String("hyderabad");
    //Internet   //Interchange
        System.out.println("str3.equals(str4)  : "+str3.equals(str4));
        System.out.println("str3 == str4  :"+(str3 == str4));
        System.out.println("str3.charAt(4) "+str3.charAt(4));
        System.out.println( "str3.toUpperCase()"+str3.toUpperCase());
        String upperCaseStr = str3.toUpperCase();
        System.out.println("str3 in UpperCase :"+upperCaseStr);
        System.out.println("upperCaseStr.toLowerCase() :"+upperCaseStr.toLowerCase());
        System.out.println("str3.length() "+str3.length());
        System.out.println("str3.compareTo(str4) "+str3.compareTo(str4));

        StringBuilder sbr = new StringBuilder("Hello World");
        sbr.append('F');
        System.out.println("sbr AFter appending "+sbr);
       sbr.insert(6,"New ");
        System.out.println("sbr After Inserting "+sbr);

        StringBuffer sbfr = new StringBuffer("Internet Things");
        System.out.println("sbr before insert "+sbfr);
        sbfr.insert(9,"Of ");
        System.out.println("sbr after insert : "+sbfr);
       // www.rediff.com?login=jasjdksakljlj&lpaswd=jaksjj
        //StringTokenizer

    }

    public static void main(String[] args) {
        StringFunctionSample sfs = new StringFunctionSample();
        sfs.checkStringBehaviour();
    }

}
