package com.ford.sep27;

public class CalculatorNew {

    int result;
    public int divideNum1ByNum2(int numerator, int denominator)
    {
        System.out.println("We are Entering into a Calculation Method");
        System.out.println("We are about to calculate...");
        try
        {
           result  = numerator / denominator;
        }
        catch(ArithmeticException ae)
        {
            ae.printStackTrace();
            throw ae;
        }
        System.out.println("We finished Calculation");
        System.out.println("We are ABout to leave function..");
        return result;
    }
}
