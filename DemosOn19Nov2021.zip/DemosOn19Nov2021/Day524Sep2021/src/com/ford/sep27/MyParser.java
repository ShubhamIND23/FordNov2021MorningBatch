package com.ford.sep27;

public class MyParser {



    public static void main(String[] args) {
        Parser p;
        Implementor impl = new Implementor();
         p = new XMLParser();
      //   p.parseFile("XMLFile.....");
        impl.callParser(p,"XMLFile");
         p = new JsonParser();
      //   p.parseFile("JSONFile");
        impl.callParser(p,"JSONFile");
         p = new PDFParser();
       //  p.parseFile("PDFFile");
        impl.callParser(p,"PDFFile");
       // Parser p = new Parser();
        p.displayMethod();


    }
}
