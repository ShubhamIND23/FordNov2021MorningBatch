package com.ford.collections;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSample {

   ArrayList employees;

    public ArrayListSample() {
        employees = new ArrayList();
    }

    public void populateEmployeesArrayList()
    {
        employees.add(new Employee("E001","Harsha","RTNagar","9829929922",2345.56f));
        employees.add(new Employee("E002","Keerthana","Vijayanagar","9829934522",4345.56f));
        employees.add(new Employee("E003","Ramesh Kumar","Jayanagar","9845629922",3345.56f));
        employees.add(new Employee("E004","Vijayan","RTNagar","9829925672",1345.56f));
        employees.add(new Employee("E005","Roopesh","Malleswaram","9878929922",5345.56f));

    }

    public boolean fetchEmployees()
    {
        boolean flag = false;
        populateEmployeesArrayList();

    /*    if(employees.isEmpty() == false)
        {
            Iterator empIter = employees.iterator();
            System.out.println("The Employees details are...");
            while(empIter.hasNext())
            {
                Employee emp1 = (Employee)empIter.next();
                System.out.println(emp1);
            }
            flag = true;
        }*/

        if(employees.isEmpty() == false)
        {
            for(Object e:employees)
            {
                System.out.println("The Employee "+(Employee)e);
            }
            flag = true;
        }
        Employee e =  (Employee)employees.get(4);
        System.out.println("the Employee at index 5 "+e);
        employees.remove(3);

        System.out.println("The Size after Removing one Employee "+employees.size());
        System.out.println("-----------after removal-----");
        if(employees.isEmpty() == false)
        {
            for(Object e1:employees)
            {
                System.out.println("The Employee "+(Employee)e1);
            }
            flag = true;
        }

        return flag;

    }
}
