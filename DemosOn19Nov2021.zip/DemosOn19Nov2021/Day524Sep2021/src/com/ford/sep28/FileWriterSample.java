package com.ford.sep28;

import java.io.*;

public class FileWriterSample {

    public void readFromCharStream()
    {
        int chars;
        try {
            FileReader fr = new FileReader("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\Files\\supplier.txt");
            while((chars = fr.read()) != -1)
            {
                System.out.print((char)chars);
            }
        }
        catch(FileNotFoundException fnfe)
        {
            fnfe.printStackTrace();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }
    public void writeToCharStream()
    {

        File file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\Files\\supplier.txt");
        try
        {
            FileWriter fw = new FileWriter(file1);
            fw.write("welcome to files");
            System.out.println("Written into file successfully");
            fw.flush();
            fw.close();
        }
        catch(FileNotFoundException fnfe)
        {
            fnfe.printStackTrace();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }

    }

    public static void main(String[] args) {
        FileWriterSample fws = new FileWriterSample();
       // fws.writeToCharStream();
        fws.readFromCharStream();
    }
}
