package com.ford.sep28;
//extends MyFinalClass not possible
public class MySalaryCalculator  {

    public final void displayIncentives()
    {
        System.out.println("Incentive is 13 Percent");
    }


}
