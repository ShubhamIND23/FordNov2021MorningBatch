package com.ford.sep28;

public final class MyFinalClass {

    int bonus;
    public void calculate(int a, int b)
    {
        int result = a + b;
        System.out.println("The sum is "+result);
    }
    public final void displayBonus()
    {
        bonus = 20;
        System.out.println("The Bonus is "+bonus);
    }
}
