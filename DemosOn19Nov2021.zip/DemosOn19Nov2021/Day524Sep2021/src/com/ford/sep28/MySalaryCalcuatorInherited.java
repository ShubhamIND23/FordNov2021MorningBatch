package com.ford.sep28;

public class MySalaryCalcuatorInherited extends MySalaryCalculator{


}
