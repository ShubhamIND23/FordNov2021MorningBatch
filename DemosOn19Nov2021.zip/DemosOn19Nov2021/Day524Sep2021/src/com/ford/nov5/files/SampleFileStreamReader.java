package com.ford.nov5.files;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class SampleFileStreamReader {
    File file1;
    FileInputStream fis;
    byte myBytes[] = new byte[100];
    boolean flag = false;
    public boolean readFromFileStream() {
        String pathName = "C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch04-01Nov2021AN\\Files\\Customer.txt";
        file1 = new File(pathName);
        try {
            fis = new FileInputStream(file1);
            fis.read(myBytes);
            String readStr = new String(myBytes);
            System.out.println("The Data Read from File is "+readStr);
            flag = true;
            fis.close();
        }
        catch(FileNotFoundException fnfe)
        {
            fnfe.printStackTrace();
            flag = false;
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            flag = false;
        }
        return flag;
    }

}
