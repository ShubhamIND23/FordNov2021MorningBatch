package com.ford.nov5.anoonexceptions;

public class ArrayExceptionSample {
    public boolean manipulateArray(int array1[], int index )
    {
        boolean flag = false;
        try {
            for (int i = 0; i < index; i++) {
                array1[i] = (i + 1) * 10;
                System.out.println("The Array Element is " + array1[i]);
                flag = true;
            }
        }
        catch(ArrayIndexOutOfBoundsException ae)
        {
            ae.printStackTrace();
            flag = false;
            throw ae;
        }
            return flag;

    }

    public String getCountryByIndex(String[] countries,String strIndex)
    {

        String myCountry;
        try {
            myCountry = countries[Integer.parseInt(strIndex)];
            System.out.println("The Country is "+myCountry);
        }
        catch(ArrayIndexOutOfBoundsException ae)
        {
            ae.printStackTrace();
            throw ae;
        }
        catch(NumberFormatException nfe)
        {
            nfe.printStackTrace();
            throw nfe;
        }
       return myCountry;
    }


}
