package com.ford.nov5.anoonexceptions;

import com.ford.morn.nov05exceptions.InvalidAgeException;

public class Recruitment {

    private void checkAge(int age) throws InvalidAgeException
    {
        if(age >= 20 && age <= 30) {
            System.out.println("Valid Age Eligible for Recruitment..."+age);
        }
        else
        {
           /* InvalidAgeException iax = new InvalidAgeException("error msg")
                    throw iax; */
            throw new InvalidAgeException("Valid Age is between 20 and 30 Including Limits...");
        }
    }
    public boolean scrutinizeAge(int age) throws InvalidAgeException
    {
        boolean flag = false;
        System.out.println("Age Verification Started...");
        try
        {
            checkAge(age);
            flag = true;
        }
        catch(InvalidAgeException iae)
        {
            iae.printStackTrace();
            System.out.println(iae);
           // flag = false;
            throw iae;
        }
        System.out.println("Age Verification Completed...Further Scrutiny to Continue...");
        return flag;
    }

    public static void main(String[] args) throws InvalidAgeException {
        System.out.println("Recruitment Process Started....");
        Recruitment rc = new Recruitment();
        /*try { */
            rc.scrutinizeAge(24);
            rc.scrutinizeAge(22);
            rc.scrutinizeAge(35);
            rc.scrutinizeAge(27);
            rc.scrutinizeAge(26);
      /*  }
        catch(InvalidAgeException iae)
        {
            iae.printStackTrace();
            System.out.println(iae);
            throw iae;
        }*/
        System.out.println("Recruitment Process Completed...");
    }
}
