package com.ford.nov12.anoon.functional;

public interface Customer {
    public void calculateInvoiceAmt(int qty,int price);
}
