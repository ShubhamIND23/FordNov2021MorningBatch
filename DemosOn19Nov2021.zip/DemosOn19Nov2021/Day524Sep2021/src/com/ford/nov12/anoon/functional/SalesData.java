package com.ford.nov12.anoon.functional;

public interface SalesData {
    public void processOrder(int qty,int price,NewCustomer nc);
}
