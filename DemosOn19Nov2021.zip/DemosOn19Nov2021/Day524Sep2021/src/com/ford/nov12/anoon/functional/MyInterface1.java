package com.ford.nov12.anoon.functional;
//Functional Interface Declaration/Definition
public interface MyInterface1 {
    public void display();
}

