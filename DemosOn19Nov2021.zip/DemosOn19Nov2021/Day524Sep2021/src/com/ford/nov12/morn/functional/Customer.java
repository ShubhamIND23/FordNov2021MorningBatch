package com.ford.nov12.morn.functional;

public interface Customer {
    public void calculateInvoice(int qty,int price);
}
