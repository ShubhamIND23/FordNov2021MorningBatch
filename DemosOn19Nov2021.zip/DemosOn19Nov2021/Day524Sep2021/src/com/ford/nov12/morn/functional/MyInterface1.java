package com.ford.nov12.morn.functional;

public interface MyInterface1 {
    public void display1();
}

