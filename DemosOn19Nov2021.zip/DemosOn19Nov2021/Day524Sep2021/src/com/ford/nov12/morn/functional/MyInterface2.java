package com.ford.nov12.morn.functional;

public interface MyInterface2 {
    public void calculate(int a,int b);
}
