package com.ford.nov12.morn.functional;

public interface SalesData {
    public void processOrder(int qty,int price,NewCustomer c);
}
