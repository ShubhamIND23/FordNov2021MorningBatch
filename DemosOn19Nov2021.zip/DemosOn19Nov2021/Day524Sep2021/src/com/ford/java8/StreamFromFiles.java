package com.ford.java8;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamFromFiles {
    public long readFile(String filePath) {

        Path path = Paths.get(filePath);

        if (!Files.exists(path)) {
            System.out.println("The file " + path.toAbsolutePath() + " doesn't exist.");
            return -1;
        }
        long lineCount = 0;
        Stream<String> lines;
        try {
          //  lines = Files.lines(path);
           // lines =  Files.lines(path);
           List <String> myList =  Files.lines(path).collect(Collectors.toList());
                    lineCount =  Files.lines(path).count();
            System.out.println(myList);
            System.out.println("the Line Count "+lineCount);

            System.out.println(myList);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return lineCount;

    }

    public static void main(String... args) {

        StreamFromFiles streamsFromFiles = new StreamFromFiles();
        streamsFromFiles.readFile("src\\com\\ford\\java8\\StreamFromFiles.java");
    }
}
