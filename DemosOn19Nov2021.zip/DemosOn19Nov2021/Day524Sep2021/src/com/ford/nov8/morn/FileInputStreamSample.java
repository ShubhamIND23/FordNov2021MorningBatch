package com.ford.nov8.morn;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamSample {
    FileInputStream fis;
    File file1;
    byte myBytes[] = new byte[100];
    boolean flag = false;
    public boolean readFromStream()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\Customer.txt");
       try {
           fis = new FileInputStream(file1);
           fis.read(myBytes);
           String readStr = new String(myBytes);

           flag = true;
           System.out.println("The Data Read from File is :"+readStr);
           fis.close();
       }
       catch(FileNotFoundException fnfe)
       {
           fnfe.printStackTrace();
           flag = false;
       }
       catch(IOException ioe)
       {
           ioe.printStackTrace();
           flag = false;
       }
        return flag;
    }
}
