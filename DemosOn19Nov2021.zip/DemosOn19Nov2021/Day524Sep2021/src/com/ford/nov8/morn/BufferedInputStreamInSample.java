package com.ford.nov8.morn;

import java.io.BufferedInputStream;
import java.io.IOException;

public class BufferedInputStreamInSample {

    BufferedInputStream bisReader;
    boolean flag = false;
    byte[] myBytes = new byte[100];
    public boolean readFromKeyBoardThruBuffer()
    {
        bisReader = new BufferedInputStream(System.in);

        //String str = scan1.nextLine();
        try {
            System.out.println("Please enter a String");
            bisReader.read(myBytes);
            String readStr = new String(myBytes);
            System.out.println("The Data Read from KeyBoard is "+readStr);

            bisReader.close();
            flag = true;
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            flag = false;
        }
        return flag;
    }

    public static void main(String[] args) {
        BufferedInputStreamInSample biss = new BufferedInputStreamInSample();
        biss.readFromKeyBoardThruBuffer();
    }

}
