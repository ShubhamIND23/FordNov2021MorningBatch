package com.ford.nov8.noon;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class SampleFileWriter {
    FileWriter fWriter;
    File file1;
    boolean flag = false;
    String str = new String("We wrote into Char Stream file...");
    public boolean writeToCharFile()
    {
        String pathName = "C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch04-01Nov2021AN\\Files\\Supplier.txt";
        file1 = new File(pathName);
        try {
            fWriter = new FileWriter(file1);
            fWriter.write(str);
            flag = true;
            System.out.println("We have written successfully into Char Stream File...");
            fWriter.flush();
            fWriter.close();
        }
        catch(FileNotFoundException fnfe)
        {
            fnfe.printStackTrace();
            flag = false;
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            flag = false;
        }
        return flag;
    }

}
