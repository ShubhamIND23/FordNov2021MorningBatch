package com.ford.nov8.noon;

import java.io.BufferedInputStream;
import java.io.IOException;

public class BufferedInputStreamInSample {

    BufferedInputStream bisReader;
    boolean flag = false;
    byte[] myBytes = new byte[100];
    public void readFromKeyBoardThruBuffer()
    {
        bisReader = new BufferedInputStream(System.in);
        System.out.println("Please enter a String...");
        String readStr;
        try {
            bisReader.read(myBytes);
            readStr = new String(myBytes);
            System.out.println(" The Data That was Read :"+readStr);
            bisReader.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }

    }

    public static void main(String[] args) {
        BufferedInputStreamInSample biss = new BufferedInputStreamInSample();
        biss.readFromKeyBoardThruBuffer();
    }

}
