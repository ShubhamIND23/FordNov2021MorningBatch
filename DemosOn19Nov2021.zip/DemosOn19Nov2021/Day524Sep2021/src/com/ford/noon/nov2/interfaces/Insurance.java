package com.ford.noon.nov2.interfaces;

public interface Insurance {
    public void createPolicy();
    public void terminatePolicy();
    public void calculatePremium();
}
