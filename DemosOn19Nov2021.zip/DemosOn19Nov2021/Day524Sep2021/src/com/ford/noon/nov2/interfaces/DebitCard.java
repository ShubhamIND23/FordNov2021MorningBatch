package com.ford.noon.nov2.interfaces;

public interface DebitCard extends Banking{
    public void checkBalance();
    public void withdrawAmt();
    public void depositAmt();
}
