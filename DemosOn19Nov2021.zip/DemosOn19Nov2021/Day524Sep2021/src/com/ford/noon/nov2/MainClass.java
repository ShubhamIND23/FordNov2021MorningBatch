package com.ford.noon.nov2;

public class MainClass {
    public static void main(String[] args) {

        Parser parser;
        Implementor implementor = new Implementor();

        parser = new XMLParser();
        parser.parseFile("XMLFile");

        implementor.callParser(parser,"XMLFile");

        parser = new JSONParser();
        implementor.callParser(parser,"JSONFile");

        parser = new PDFParser();
        implementor.callParser(parser,"PDFFile");

        // Parser parse1 = new Parser(); ABstract Class cannot be instantiated

    }

}
