package com.ford.noon.nov2;

public class MyMainClass /*extends MyFinalClass*/ {

    public static void main(String[] args) {

        MyFinalClass mfc = new MyFinalClass();
        mfc.method1();
        mfc.method2();
    }
}
