package com.ford.noon.nov2.interfaces;

public interface CreditCard extends Banking,Insurance{

    public void calculateCCInterest();
    public void calculateRedemptionPoints();
    public void calculateOutStanding();
}
