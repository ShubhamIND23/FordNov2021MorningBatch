package com.ford.nov02;

public abstract class Parser implements Interface1{
  public abstract void parseFile(String fileType);

    public void viewContents()
    {
        System.out.println("Viewing Contents of a File ");
    }

    @Override
    public abstract void method1() ;
}
