package com.ford.nov9.morn;

import java.io.*;

public class DeSerializationSample {
    ObjectInputStream oiStream;
    File file1;
    boolean flag = false;

    public boolean deSerializeObject()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\eEmployees.txt");

        try {
            oiStream = new ObjectInputStream(new FileInputStream(file1));
            /* while writing if
            ArrayList <Employee> employees = new ArrayList<Employee>()
            opStream.writeObject(employees);
            while reading Object o
            ArrayList <Employee> myEmployees = (ArrayList<Employee> )oiStream.readObject();
             */
            //   Employee employee = (Employee)oiStream.readObject();
            Employee[] employees = (Employee[])oiStream.readObject();
            System.out.println("The DeSerialized Object - Employees are ...");
            for(int i=0;i< employees.length;i++)
            {
                System.out.println(employees[i]);
            }
        oiStream.close();
            flag = true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            flag = false;
        } catch(ClassNotFoundException cnfe)
        {
            cnfe.printStackTrace();
            flag = false;
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            flag = false;
        }
    return flag;

    }

}
