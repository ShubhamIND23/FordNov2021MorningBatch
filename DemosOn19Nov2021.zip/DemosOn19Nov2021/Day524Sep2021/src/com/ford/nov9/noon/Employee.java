package com.ford.nov9.noon;

import java.io.Serializable;

public class Employee implements Serializable {

    String employeeId;
    String employeeName;
    String employeeAddress;
    String employeePhone;
    float employeeSalary;
    transient float incomeTax;

    public Employee() {
    }

    public Employee(String employeeId, String employeeName, String employeeAddress, String employeePhone, float employeeSalary) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.employeeAddress = employeeAddress;
        this.employeePhone = employeePhone;
        this.employeeSalary = employeeSalary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeId='" + employeeId + '\'' +
                ", employeeName='" + employeeName + '\'' +
                ", employeeAddress='" + employeeAddress + '\'' +
                ", employeePhone='" + employeePhone + '\'' +
                ", employeeSalary=" + employeeSalary +
                ", incomeTax=" + incomeTax +
                '}';
    }
}
