package com.ford.nov10.noon;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListGenerics {

    ArrayList myList;
    public void displayArrayListElements()
    {

        ArrayList <Customer> myList1 = new ArrayList<Customer>();
        myList = new ArrayList();
        int num1 = 2000;
       // Integer int1 = new Integer(num1);
        myList.add(num1);
        myList.add("Hello");
        myList.add(new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1"));
        myList.add(2345.67);
        myList.add(true);

        Iterator objIter = myList.iterator();
        while(objIter.hasNext())
        {
          //  Customer c = (Customer)objIter.next();
            Object obj = objIter.next();
            System.out.println(obj);
        }

    }

    public static void main(String[] args) {

        ArrayListGenerics alGenerics = new ArrayListGenerics();
        alGenerics.displayArrayListElements();

    }
}
