package com.ford.nov10.noon;

import java.util.ArrayList;
import java.util.Iterator;

public class GenericArrayListSample {

    ArrayList <Customer> customers;
    boolean flag;
    public GenericArrayListSample()
    {
        flag = false;

    }
    public ArrayList <Customer> populateCustomers()
    {
        customers = new ArrayList<Customer>();
       // customers = new ArrayList();
        Customer c1 = new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1");
        customers.add(c1);
        customers.add(new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2"));
        customers.add(new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3"));
        customers.add(new Customer("C004","Kiran","Malleswaram","9849996798",4000.0f,"Product4"));
        customers.add(new Customer("C005","Rakesh","Vijayanagar","9834999498",5000.0f,"Product5"));

            return customers;
    }

    public ArrayList <Customer> displayGenericArrayListElements()
    {
        ArrayList <Customer> customers = populateCustomers();
        Iterator <Customer> custIter ;
        System.out.println("Customer Details Through Generic Collection Object are...");
        try {
            custIter = customers.iterator();
            while (custIter.hasNext()) {
                Customer customer = custIter.next();
                System.out.println(customer);
            }
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
        }
        return customers;

    }


}
