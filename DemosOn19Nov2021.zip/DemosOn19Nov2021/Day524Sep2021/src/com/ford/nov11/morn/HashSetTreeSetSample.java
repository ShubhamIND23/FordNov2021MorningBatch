package com.ford.nov11.morn;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashSetTreeSetSample {

    HashSet <String> hSet;
    TreeSet <String> tSet;
    public HashSetTreeSetSample()
    {
        hSet = new HashSet<String>();
        tSet = new TreeSet<String>();
    }

    public void populateHashSet()
    {
        hSet.add("Emanuel");
        hSet.add("David");
        hSet.add("Zeenat");
        hSet.add("Yasmeen");
        hSet.add("Amarnath");
        hSet.add("Chandan");
        hSet.add("Faheem");
        hSet.add("Faheem");
    }
    public void populateTreeSet()
    {
        tSet.add("Emanuel");
        tSet.add("David");
        tSet.add("Zeenat");
        tSet.add("Yasmeen");
        tSet.add("Amarnath");
        tSet.add("Chandan");
        tSet.add("Faheem");
        tSet.add("Faheem");
    }
    public void fetchHashSetObjects()
    {
        Iterator <String> hsIter = hSet.iterator();
        while(hsIter.hasNext())
        {
            String sObj = hsIter.next();
            System.out.println(sObj);
        }

    }
    public void fetchTreeSetObjects()
    {
        Iterator <String> tsIter = tSet.iterator();
        while(tsIter.hasNext())
        {
            String sObj = tsIter.next();
            System.out.println(sObj);
        }
    }

    public static void main(String[] args) {
        HashSetTreeSetSample hstsSample = new HashSetTreeSetSample();
        hstsSample.populateHashSet();
        hstsSample.fetchHashSetObjects();
        System.out.println("-----------------------------------");
        hstsSample.populateTreeSet();
        hstsSample.fetchTreeSetObjects();
    }

}
