package com.ford.nov11.noon;

import java.util.Iterator;
import java.util.Stack;

public class StackSample {

    Stack <Customer> customerStack;
    boolean flag;
    /*
    Customer c1 = new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1");
      customers.add(c1);
      customers.add(new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2"));
      customers.add(new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3"));
      customers.add(new Customer("C004","Kiran","Malleswaram","9849996798",4000.0f,"Product4"));
      customers.add(new Customer("C005","Rakesh","Vijayanagar","9834999498",5000.0f,"Product5"));

   */
    public StackSample()
    {
        customerStack = new Stack<Customer>();
        flag = false;
        customerStack.push(new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1"));
        customerStack.push(new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2"));
        customerStack.push(new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3"));
        customerStack.push(new Customer("C004","Kiran","Malleswaram","9849996798",4000.0f,"Product4"));
        customerStack.push(new Customer("C005","Rakesh","Vijayanagar","9834999498",5000.0f,"Product5"));

    }

    public boolean fetchStackElementsThruPop()
    {

        try {
            while (customerStack.isEmpty() == false) {
                Customer customer = customerStack.pop();
                System.out.println("The Popped Element is " + customer);
            }
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean fetchStackElementsThruIterator()
    {

        Iterator <Customer> custIter = customerStack.iterator();
        try
        {
            while(custIter.hasNext())
            {
                Customer customer = custIter.next();
                System.out.println("Element Fetched "+customer);
            }
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
        return flag;
    }

    public static void main(String[] args) {

        StackSample stackSample = new StackSample();


        stackSample.fetchStackElementsThruPop();
        System.out.println("-----------------------------");
        StackSample stackSample1 = new StackSample();
        stackSample1.fetchStackElementsThruIterator();
    }

}
