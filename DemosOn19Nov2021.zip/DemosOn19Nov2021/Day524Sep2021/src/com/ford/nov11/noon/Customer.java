package com.ford.nov11.noon;

public class Customer implements Comparable <Customer> {


    String customerId;
    String customerName;
    String customerAddress;
    String customerPhone;
    float purchaseValue;
    String productName;

    public Customer() {
    }

    public Customer(String customerId, String customerName, String customerAddress, String customerPhone, float purchaseValue, String productName) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.customerPhone = customerPhone;
        this.purchaseValue = purchaseValue;
        this.productName = productName;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public float getPurchaseValue() {
        return purchaseValue;
    }

    public void setPurchaseValue(float purchaseValue) {
        this.purchaseValue = purchaseValue;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerId='" + customerId + '\'' +
                ", customerName='" + customerName + '\'' +
                ", customerAddress='" + customerAddress + '\'' +
                ", customerPhone='" + customerPhone + '\'' +
                ", purchaseValue=" + purchaseValue +
                ", productName='" + productName + '\'' +
                '}';
    }
    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Customer)) {
            return false;
        }
        Customer customer = (Customer) obj;
        return customerId.equals(customer.customerId)
                && customerName.equals(customer.customerName)
                && customerAddress.equals(customer.customerAddress)
                && customerPhone.equals(customer.customerPhone)
                && Float.compare(purchaseValue, customer.purchaseValue) == 0
                && productName.equals(customer.productName) ;
    }

    @Override
    public int compareTo(Customer o) {
        return 0;
    }
}
/*
1 / -1 /0
* */