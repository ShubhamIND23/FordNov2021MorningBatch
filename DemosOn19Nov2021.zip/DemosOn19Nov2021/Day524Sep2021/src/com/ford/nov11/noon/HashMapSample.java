package com.ford.nov11.noon;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class HashMapSample {

    HashMap<String,Customer> hashMap;
    boolean flag;

    public HashMapSample()
    {
        flag = false;
        hashMap = new HashMap<String,Customer>();
        hashMap.put("C001",new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1"));
        hashMap.put("C002",new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2"));
        hashMap.put("C003",new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3"));
        hashMap.put("C004",new Customer("C004","Kiran","Malleswaram","9849996798",4000.0f,"Product4"));
        hashMap.put("C005",new Customer("C005","Rakesh","Vijayanagar","9834999498",5000.0f,"Product5"));
        hashMap.put("C005",new Customer("C005","Rajesh","Koramangala","9864599498",5000.0f,"Product5"));

    }
    public boolean fetchHashMapObjectsThruKeySet()
    {
        Set <String> myKeys;
        try
        {
            myKeys = hashMap.keySet();

            Iterator <String> keyIter = myKeys.iterator();
            while(keyIter.hasNext())
            {
                String key = keyIter.next();
                Customer customer = hashMap.get(key);
                System.out.println("The Value for the Key : "+key+" is :"+customer);
            }
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
