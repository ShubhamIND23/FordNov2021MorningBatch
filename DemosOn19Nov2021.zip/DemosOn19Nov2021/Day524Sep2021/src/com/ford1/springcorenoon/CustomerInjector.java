package com.ford1.springcorenoon;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CustomerInjector {
    ApplicationContext context;
    boolean flag = false;
    public boolean injectCustomerNProducts()
    {
        try {
            context = new ClassPathXmlApplicationContext("CustomerContext.xml");
            Customer customer = context.getBean("customer1", Customer.class);
            customer.displayCustomerDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
