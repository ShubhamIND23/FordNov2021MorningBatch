package com.ford1.springcorenoon;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeInjector {
    ApplicationContext context;
    public boolean injectEmployee1()
    {

        boolean flag = false;
        try {
            context = new ClassPathXmlApplicationContext("ApplicationContextn.xml");
            Employee employee1 = (Employee) context.getBean("employee1");
            employee1.displayEmployeeDetails();
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
            return flag;

    }
    public boolean injectEmployee2()
    {

        boolean flag = false;
        try {
            context = new ClassPathXmlApplicationContext("ApplicationContextn.xml");
            Employee employee2 = (Employee) context.getBean("employee2");
            employee2.displayEmployeeDetails();
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
        return flag;

    }
    public boolean injectEmployee3()
    {

        boolean flag = false;
        try {
            context = new ClassPathXmlApplicationContext("ApplicationContextn.xml");
            Employee employee3 = (Employee) context.getBean("employee3");
            employee3.displayEmployeeDetails();
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
        return flag;

    }
    public boolean injectEmployee4()
    {
        boolean flag = false;
        try
        {
            context = new ClassPathXmlApplicationContext("ApplicationContextn.xml");
            Employee employee4 = (Employee) context.getBean("employee4");
            employee4.displayEmployeeDetails();
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
