package com.ford1.springcorenoon;

import java.util.Iterator;
import java.util.List;

public class Customer {
    String customerId;
    String customerName;
    String customerPhone;
    Address customerAddress;
    List <String> products;

    public Customer() {
    }

    public Customer(String customerId, String customerName, String customerPhone, Address customerAddress, List<String> products) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerPhone = customerPhone;
        this.customerAddress = customerAddress;
        this.products = products;
    }
    public void displayCustomerDetails()
    {
        System.out.println("Customer Details are ...");
        System.out.println("Customer Id :"+customerId);
        System.out.println("Customer Name :"+customerName);
        System.out.println("Customer Phone :"+customerPhone);
        System.out.println("Customer Address :"+customerAddress);
        System.out.println("The Products Purchased by the Customer are ...");
        Iterator <String> prodIter = products.iterator();
        while(prodIter.hasNext())
        {
            String product = prodIter.next();
            System.out.println(product);
        }
    }
}
