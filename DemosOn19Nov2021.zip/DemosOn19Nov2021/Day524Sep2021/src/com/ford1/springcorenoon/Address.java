package com.ford1.springcorenoon;

public class Address {
    String dNo;
    String street;
    String city;
    String state;

    public Address(String dNo, String street, String city, String state) {
        this.dNo = dNo;
        this.street = street;
        this.city = city;
        this.state = state;
    }

    @Override
    public String toString() {
        return "Address{" +
                "dNo='" + dNo + '\'' +
                ", street='" + street + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
