package com.ford1.springcore;

import java.util.Iterator;
import java.util.List;

public class Customer {
    String customerId;
    String customerName;
    String customerPhone;
    float purchaseValue;
    List <String> products;

    public Customer() {
    }



    public Customer(String customerId, String customerName) {
        this.customerId = customerId;
        this.customerName = customerName;
    }

    public Customer(String customerId, String customerName, String customerPhone) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerPhone = customerPhone;
    }

    public Customer(String customerId, String customerName, String customerPhone, float purchaseValue) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerPhone = customerPhone;
        this.purchaseValue = purchaseValue;
    }

    public Customer(String customerId, String customerName, String customerPhone, float purchaseValue, List<String> products) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerPhone = customerPhone;
        this.purchaseValue = purchaseValue;
        this.products = products;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerId='" + customerId + '\'' +
                ", customerName='" + customerName + '\'' +
                ", customerPhone='" + customerPhone + '\'' +
                ", purchaseValue=" + purchaseValue +
                '}';
    }
    public void displayCustomerDetails()
    {
        System.out.println("Customer Details are ....");
        System.out.println("Customer Id :"+customerId);
        System.out.println("Customer Name :"+customerName);
        System.out.println("Customer Phone :"+customerPhone);
        System.out.println("Purchase Value  :"+purchaseValue);
        System.out.println("Products Purchased are :");
        Iterator <String> prodIter = products.iterator();
        while(prodIter.hasNext())
        {
            String product = prodIter.next();
            System.out.println(product);
        }
        System.out.println("-----------------------------");
    }

}
