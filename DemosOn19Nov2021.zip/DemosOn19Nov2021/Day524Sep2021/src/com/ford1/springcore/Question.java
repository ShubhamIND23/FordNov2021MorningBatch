package com.ford1.springcore;

import java.util.Iterator;
import java.util.List;

public class Question {

    String questionId;
    String question;
    List <Answer> answerList;

    public Question() {
    }

    public Question(String questionId, String question, List<Answer> answerList) {
        this.questionId = questionId;
        this.question = question;
        this.answerList = answerList;
    }
    public void displayQuestionAndAnswers()
    {
        System.out.println("The Question Details are ....");
        System.out.println("Question Id is : "+questionId);
        System.out.println("Question is :"+question);
        System.out.println("The Various answers Provided are :");
        Iterator <Answer> ansIter = answerList.iterator();
        while(ansIter.hasNext())
        {
            Answer answer = ansIter.next();
            System.out.println(answer);
        }

    }
}
