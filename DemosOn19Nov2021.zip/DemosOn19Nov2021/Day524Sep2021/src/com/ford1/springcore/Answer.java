package com.ford1.springcore;

import java.util.List;

public class Answer {
    String ansId;
    String answeredBy;
    List <String> answers;

    public Answer() {
    }

    public Answer(String ansId, String answeredBy, List<String> answers) {
        this.ansId = ansId;
        this.answeredBy = answeredBy;
        this.answers = answers;
    }

    @Override
    public String toString() {
        return "Answer{" +
                "ansId='" + ansId + '\'' +
                ", answeredBy='" + answeredBy + '\'' +
                ", answers=" + answers +
                '}';
    }
}
