package com.ford1.springcore;

public class Address {

    String number;
    String street;
    String city;
    String state;

    public Address() {
    }

    public Address(String number, String street, String city, String state) {
        this.number = number;
        this.street = street;
        this.city = city;
        this.state = state;
    }

    @Override
    public String toString() {
        return "Address{" +
                "number='" + number + '\'' +
                ", street='" + street + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
