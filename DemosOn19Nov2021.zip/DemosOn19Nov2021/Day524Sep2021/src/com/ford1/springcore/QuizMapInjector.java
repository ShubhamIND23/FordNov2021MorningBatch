package com.ford1.springcore;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class QuizMapInjector {
    ApplicationContext context;
    boolean flag = false;

    public boolean injectQuizMap1()
    {
        try
        {
            context = new ClassPathXmlApplicationContext("QuizMapContext.xml");
            QuizMap quizMap1 = (QuizMap)context.getBean("quizMap1");
            quizMap1.displayQuizMapDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
           return flag;
    }
    public boolean injectQuizMap2()
    {
        /*
        Resource resource = new ClassPathResource("applicationContext.xml");
		BeanFactory myFactory = new XmlBeanFactory(resource);
		EmployeeBean empBean1 = (EmployeeBean)myFactory.getBean("emp2");
         */
        try
        {
          /*  context = new ClassPathXmlApplicationContext("QuizMapContext.xml");
            QuizMap quizMap1 = (QuizMap)context.getBean("quizMap2");*/

            Resource resource = new ClassPathResource("QuizMapContext.xml");
            BeanFactory myFactory = new XmlBeanFactory(resource);
            QuizMap quizMap1 = (QuizMap) myFactory.getBean("quizMap2");

            quizMap1.displayQuizMapDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
