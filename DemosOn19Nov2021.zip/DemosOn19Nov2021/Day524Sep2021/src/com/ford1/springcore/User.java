package com.ford1.springcore;

public class User {

    String userId;
    String userName;
    String designation;

    public User() {

    }

    public User(String userId, String userName, String designation) {
        this.userId = userId;
        this.userName = userName;
        this.designation = designation;
    }

    @Override
    public String toString() {
        return "User{" +
                "userId='" + userId + '\'' +
                ", userName='" + userName + '\'' +
                ", designation='" + designation + '\'' +
                '}';
    }
}
