public class TypeCastingSample {

    public static void main(String[] args) {

        byte bVar = 125;
        int iVar = 0;
        //Wide Casting - Implicit Casting
        iVar = bVar;
        System.out.println("the int variable after receiving data from byte variable "+iVar);

        int iVar1 = 125;
        //NarrowCasting - Expicit Casting
        bVar = (byte)iVar1;
        System.out.println("the Narrow Casted byteVar after receiving from int "+bVar);

        int iVar2 = 516;
        //NarrowCasting - Expicit Casting
        bVar = (byte)iVar2;
        System.out.println("the Narrow Casted byteVar after receiving from int "+bVar);
        // 130 - 256 = -126

        float fVar = 65300.23f;
        short sVar1;
        sVar1 = (short)fVar;
        System.out.println("the Float value in short "+sVar1);

    }
}
