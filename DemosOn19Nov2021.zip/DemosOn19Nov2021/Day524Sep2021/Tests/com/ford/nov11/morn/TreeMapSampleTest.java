package com.ford.nov11.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TreeMapSampleTest {

    TreeMapSample tmSample;
    @BeforeEach
    void setUp() {
        tmSample = new TreeMapSample();
    }

    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldFetchTreeMapObjects()
    {
        assertTrue(tmSample.fetchTreeMapObjects());
    }
    @Test
    public void shouldFetchTreeMapThruKeySet()
    {
        assertTrue(tmSample.fetchTreeMapThruKeySet());
    }
}