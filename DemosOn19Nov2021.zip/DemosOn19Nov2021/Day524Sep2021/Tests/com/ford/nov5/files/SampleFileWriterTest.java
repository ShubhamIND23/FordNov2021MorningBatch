package com.ford.nov5.files;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SampleFileWriterTest {

    SampleFileWriter sfWriter;
    @BeforeEach
    void setUp() {
        sfWriter = new SampleFileWriter();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldWriteToCharFile()
    {
        assertTrue(sfWriter.writeToCharFile());
    }

}