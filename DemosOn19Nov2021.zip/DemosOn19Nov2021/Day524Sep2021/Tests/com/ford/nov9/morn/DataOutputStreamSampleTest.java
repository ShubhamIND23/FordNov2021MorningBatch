package com.ford.nov9.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DataOutputStreamSampleTest {
DataOutputStreamSample doiSample;
    @BeforeEach
    void setUp() {
        doiSample = new DataOutputStreamSample();
    }

    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldReadWriteDataStream()
    {
        assertTrue(doiSample.writeAndReadFromDataStream());
    }

}