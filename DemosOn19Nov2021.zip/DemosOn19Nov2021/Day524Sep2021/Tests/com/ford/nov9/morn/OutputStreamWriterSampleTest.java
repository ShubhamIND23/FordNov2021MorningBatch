package com.ford.nov9.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OutputStreamWriterSampleTest {

    OutputStreamWriterSample oWriter;
    @BeforeEach
    void setUp() {
        oWriter = new OutputStreamWriterSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldWriteCharsToStream()
    {
       assertTrue( oWriter.writeCharsToBytes());
    }

}