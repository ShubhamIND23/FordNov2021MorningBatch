package com.ford.nov10.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HashMapSampleTest {

    HashMapSample hmSample;
    @BeforeEach
    void setUp() {
        hmSample = new HashMapSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldDisplayValuesAndKeysOfHashMap()
    {
        assertTrue(hmSample.fetchAllValuesOfHashMap());
    }
}