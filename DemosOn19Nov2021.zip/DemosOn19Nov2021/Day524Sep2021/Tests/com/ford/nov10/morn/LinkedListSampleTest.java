package com.ford.nov10.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LinkedListSampleTest {
LinkedListSample llSample;
    @BeforeEach
    void setUp() {
        llSample = new LinkedListSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldDisplayLinkedList()
    {
        assertTrue(llSample.displayLinkedList());
    }
    @Test
    public void shouldDisplayLinkedListInReverse()
    {
        assertTrue(llSample.displayLinkedListInReverse());
    }
}