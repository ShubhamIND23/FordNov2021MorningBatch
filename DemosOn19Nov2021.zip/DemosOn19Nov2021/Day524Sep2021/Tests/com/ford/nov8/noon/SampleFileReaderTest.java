package com.ford.nov8.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SampleFileReaderTest {

    SampleFileReader sfReader;
    @BeforeEach
    void setUp() {
        sfReader = new SampleFileReader();
    }

    @AfterEach
    void tearDown() {

    }
    @Test
    public void shouldReadFromCharFile()
    {
        assertTrue(sfReader.readFromCharFile());
    }

}