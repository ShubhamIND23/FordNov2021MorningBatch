package com.ford.nov8.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FileReaderSampleTest {

    FileReaderSample freadSample;
    @BeforeEach
    void setUp() {
        freadSample = new FileReaderSample();
    }

    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldReadFromCharStream()
    {
        assertTrue(freadSample.readFromCharStream());
    }

}