package com.ford1.springcore;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StudentInjectorTest {

    StudentInjector studentInjector;
    @BeforeEach
    void setUp() {
        studentInjector = new StudentInjector();
    }

    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldInjectStudent1WithAddress()
    {
        assertTrue(studentInjector.injectStudent1());
    }
}