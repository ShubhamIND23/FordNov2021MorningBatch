package com.ford.morn.nov05exceptions;

public class ArrayExceptionSample {

    public String getCountryByIndex(String[] countries,String indexStr)
    {
        String myCountryByIndex;
        try {
            myCountryByIndex  = countries[Integer.parseInt(indexStr)];
            System.out.println("The Country for the Index "+indexStr+" is: "+myCountryByIndex);
        }
        catch(ArrayIndexOutOfBoundsException ae)
        {
            ae.printStackTrace();
            System.out.println("Country Not available for the Index");
            throw ae;
        }
        catch(NumberFormatException nfe)
        {
            nfe.printStackTrace();
            System.out.println("The NUmber Format is to be in integer and Not string..");
            throw nfe;
        }

        return myCountryByIndex;

    }

    public boolean manipulateArray(int index)
    {
      //  5
        // 0-9
        boolean flag = false;
        int myArr[] = new int[10];
        System.out.println("Array Manipulation Started..");
        try {
            for (int i = 0; i <= index; i++) {
                myArr[i] = (i + 1) * 10;
                System.out.println("Element is " + myArr[i]);
                flag = true;
            }
        }
        catch(ArrayIndexOutOfBoundsException ae)
        {
          ae.printStackTrace();
           // System.out.println(ae.getMessage());
            flag = false;
       //   throw ae;
        }
        System.out.println("Array Manipulation Completed..");
        return flag;
    }

    public static void main(String[] args) {
        ArrayExceptionSample aSample = new ArrayExceptionSample();
        System.out.println("We are about to manipulate array...");
        //    aSample.manipulateArray();
        System.out.println("We are  manipulated array...");
    }

}
