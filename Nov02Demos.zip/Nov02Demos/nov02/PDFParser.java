package com.ford.nov02;

public class PDFParser extends Parser{

    @Override
    public void parseFile(String fileType) {
        System.out.println(" Parsed PDF File "+fileType);
    }
    @Override
    public void method1() {

    }
}
