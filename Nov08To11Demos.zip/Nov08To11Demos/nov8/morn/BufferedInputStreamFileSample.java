package com.ford.nov8.morn;

import java.io.*;

public class BufferedInputStreamFileSample {
    BufferedInputStream bisReader;
    boolean flag = false;
    File file1;
    byte[] myBytes = new byte[100];
    public boolean readFromFileThruBuffer()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\Dealer.txt");
    try {
        bisReader = new BufferedInputStream(new FileInputStream(file1));
        bisReader.read(myBytes);
        String str = new String(myBytes);
        bisReader.close();
        System.out.println("The Data Read From file Thru Buffer is : "+str);
        flag = true;
    }
    catch(FileNotFoundException fnfe)
    {
        fnfe.printStackTrace();
        flag = false;
    }
    catch(IOException ioe)
    {
        ioe.printStackTrace();
        flag = false;
    }
        return flag;
    }

}
