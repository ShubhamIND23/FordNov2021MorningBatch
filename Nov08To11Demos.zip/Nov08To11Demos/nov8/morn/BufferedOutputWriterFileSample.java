package com.ford.nov8.morn;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class BufferedOutputWriterFileSample {
    File file1;
    BufferedOutputStream bosWriter;
    boolean flag = false;
    String str = "We are writing to File through Buffer...";
    byte[] myBytes = new byte[100];
    public boolean writeToFileThruBuffer()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\Dealer.txt");
       try {
           myBytes = str.getBytes();
           bosWriter = new BufferedOutputStream(new FileOutputStream(file1),10000);
           // bosWriter = new BufferedOutputStream(new FileOutputStream(file1),10000);
           bosWriter.write(myBytes);
           flag = true;
           System.out.println("We wrote successfully into File Through Buffer...");
           bosWriter.flush();
           bosWriter.close();
       }
       catch(FileNotFoundException fnfe)
       {
           fnfe.printStackTrace();
           flag = false;
       }
       catch(IOException ioe)
       {
           ioe.printStackTrace();
           flag = false;
       }
       return flag;
    }
}
