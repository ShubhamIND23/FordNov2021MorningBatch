package com.ford.nov10.morn;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListSample {

    LinkedList employees;
    boolean flag = false;
    public LinkedListSample()
    {
        employees = new LinkedList();
        Employee e1 = new Employee("E001","Harsha","RTNagar","9848848848",10000);
        employees.add(e1);
        employees.add(new Employee("E002","Kiran","Jayanagar","9848864548",11000));
        employees.add(new Employee("E003","Suman Kumar","Vijayanagar","9345848848",12000));
        employees.add(new Employee("E004","Sreejith","Malleswaram","9848878948",13000));
        employees.add(new Employee("E005","Mahesh Kumar","Koramangala","9843548848",14000));

    }

    public boolean displayLinkedList()
    {

        Iterator empIter = employees.iterator();
        while(empIter.hasNext())
        {
            Employee e = (Employee)empIter.next();
            System.out.println(e);
        }
        employees.addFirst(new Employee("E006","Sujith","S.G.Palya","5366377377",13500));
        employees.addLast(new Employee("E007","Sumith","N.S.Palya","5366321377",14500));
        Iterator empIter1 = employees.iterator();
        System.out.println("After adding records in beginning and at the end");
        while(empIter1.hasNext())
        {
            Employee e = (Employee)empIter1.next();
            System.out.println(e);
        }

        flag = true;
        return flag;
    }
    public boolean displayLinkedListInReverse()
    {

        Iterator empIter = employees.descendingIterator();
        while(empIter.hasNext())
        {
            Employee e = (Employee)empIter.next();
            System.out.println(e);
        }
        flag = true;
        return flag;
    }
}
