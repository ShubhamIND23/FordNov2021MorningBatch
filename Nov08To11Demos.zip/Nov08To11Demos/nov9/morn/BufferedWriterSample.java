package com.ford.nov9.morn;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterSample {
    BufferedWriter bWriter;
    boolean flag = false;
    String str = "We are writing to Char File thru Buffer";
    File file1;
    public boolean writeToFileThruBuffer()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\Student.txt");
        try {
            bWriter = new BufferedWriter(new FileWriter(file1));
            bWriter.write(str);
            flag = true;
            bWriter.flush();
            bWriter.close();
            System.out.println("We have written into File successfully..");
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            flag = false;
        }
        return flag;
    }


}
