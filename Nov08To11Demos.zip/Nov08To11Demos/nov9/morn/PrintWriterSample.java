package com.ford.nov9.morn;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class PrintWriterSample {

    PrintWriter pWriter;
    File file1;
    boolean flag = false;

    public boolean writeToPrintWriter()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\printerfile.txt");

        try {
            pWriter = new PrintWriter(new FileWriter(file1));
            pWriter.print("Name \t");
            pWriter.print("Address \t");
            pWriter.print("Phone \t");
            pWriter.print("Salary \t");
            pWriter.println();

            pWriter.print("Harsha \t");
            pWriter.print("RTNagar \t");
            pWriter.print("98484949499 \t");
            pWriter.print("10000 \t");
            pWriter.println();
/*--T BREAK------------11.34 to 11.59----*/
            pWriter.print("Suman \t");
            pWriter.print("Koramangala \t");
            pWriter.print("98464549499 \t");
            pWriter.print("12000 \t");
            pWriter.println();
            System.out.println("We have written successfully...");
            pWriter.flush();
            pWriter.close();
            flag = true;
        } catch (IOException e) {
            e.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
