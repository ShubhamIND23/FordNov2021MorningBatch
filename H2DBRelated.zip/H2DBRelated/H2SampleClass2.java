import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class H2SampleClass2 {
	 static final String JDBC_DRIVER = "org.h2.Driver";   
	 //DB_CLOSE_DELAY=-1
	 //jdbc:h2:~/test
	 static final String DB_URL = "jdbc:h2:~/test";  
	 //   static final String DB_URL = "jdbc:h2:test;DB_CLOSE_DELAY=-1";  
	   // static final String DB_URL = "jdbc:h2:~/";  
	 // static final String DB_URL = "jdbc:h2:~";  
	  //  static final String DB_URL = "jdbc:h2:mem:test";  
	   //  Database credentials 
	   static final String USER = "sa"; 
	   static final String PASS = "h2@123456"; 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn = null; 
	      PreparedStatement pstmt = null; 
	      System.out.println("hello");
	      try { 
	         // STEP 1: Register JDBC driver 
	         Class.forName(JDBC_DRIVER); 
	             
	         //STEP 2: Open a connection 
	         System.out.println("Connecting to database..."); 
	         conn = DriverManager.getConnection(DB_URL,USER,PASS); 
	       /*  stmt = conn.createStatement();
	         System.out.println("we are in h2");
	         ResultSet rs = stmt.executeQuery("select * from User");
	         while(rs.next())
	         {
	        	 System.out.println(rs.getString(1)+" "+rs.getString(2));
	         }*/
	         System.out.println("Inserting record in given database..."); 
	         pstmt = conn.prepareStatement("insert into Registration values(?,?,?,?)");
	         pstmt.setInt(1, 1);
	         pstmt.setString(2, "Ram");
	         pstmt.setString(3, "Kumar");
	         pstmt.setInt(4, 23);
	         pstmt.execute();
	         System.out.println("Inserted Record in given database..."); 
	         
	         // STEP 4: Clean-up environment 
	         pstmt.close(); 
	         conn.close(); 
	      }
	      catch(ClassNotFoundException cnfe)
	      {
	    	  cnfe.printStackTrace();
	      }catch(SQLException sqe)
	      {
	    	  sqe.printStackTrace();
	      }

	}

}
