package com.ford.nov9.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DeSerializationSampleTest {

    DeSerializationSample desSample;
    @BeforeEach
    void setUp() {
        desSample = new DeSerializationSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldDeSerializeEmployees()
    {
        assertTrue(desSample.deSerializeObject());
    }
}