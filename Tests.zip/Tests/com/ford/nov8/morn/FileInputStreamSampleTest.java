package com.ford.nov8.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FileInputStreamSampleTest {

    FileInputStreamSample finputSample;
    @BeforeEach
    void setUp() {
        finputSample = new FileInputStreamSample();
    }

    @AfterEach
    void tearDown() {

    }
    @Test
    public void shouldReadFromStream()
    {
        assertTrue(finputSample.readFromStream());
    }

}