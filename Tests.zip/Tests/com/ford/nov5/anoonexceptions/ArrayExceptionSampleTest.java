package com.ford.nov5.anoonexceptions;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArrayExceptionSampleTest {
ArrayExceptionSample aSample;
    int[] array1 = new int[10];
    String[] countries ={"India","USA","UK","Australia","Japan","Sweden"};
    int myIndex ;
    @BeforeEach
    void setUp() {
        aSample = new ArrayExceptionSample();
    }

    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldReturnTrueForManipulateArray()
    {
        //Given
        int[] array1 = new int[10];
        myIndex = 4;
        boolean myFlag = true;
        //When
       boolean  hisFlag = aSample.manipulateArray(array1,myIndex);
        //Then
        assertEquals(myFlag,hisFlag);

    }
    @Test
    public void shouldThrowArrayIndexOutOfBoundsException()
    {
        myIndex = 11;
        assertThrows(ArrayIndexOutOfBoundsException.class,() -> aSample.manipulateArray(array1,myIndex));

    }
    @Test
    public void shouldReturnCountryByIndex()
    {
        //Given
        String index = "0";
        String expCountry = "India";
        //When
        String actCountry = aSample.getCountryByIndex(countries,index);
        //Then
        assertEquals(expCountry,actCountry);

    }
    @Test
    public void shouldReturnCountryByNewIndex()
    {
        //Given
        String index = "0";
        String expCountry = "Japan";
        //When
        String actCountry = aSample.getCountryByIndex(countries,index);
        //Then
        assertNotEquals(expCountry,actCountry);

    }
    @Test
    public void shouldThrowArrayIndexOutOfBoundsExceptionForCountries()
    {
        //Given
        String index = "10";
        //Then
        assertThrows(ArrayIndexOutOfBoundsException.class, ()-> aSample.getCountryByIndex(countries,index));

    }
    @Test
    public void shouldThrowNumberFormatExceptionForCountries()
    {
        //Given
        String index = "four";

        assertThrows(NumberFormatException.class, ()-> aSample.getCountryByIndex(countries,index));
    }




}