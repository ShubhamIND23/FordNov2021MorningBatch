package com.ford.morn.nov05exceptions;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RecruitmentTest {

    Recruitment recruitment;
    @BeforeEach
    void setUp() {
        recruitment = new Recruitment();
    }

    @AfterEach
    void tearDown() {

    }
    @Test
    public void scrutinizeAgeShouldReturnTrue() throws InvalidAgeException {
        //Given
        boolean myFlag = true;
        //when
        boolean hisFlag = recruitment.scrutinizeAge(23);
        //then
        assertEquals(myFlag,hisFlag);

    }
    @Test
    public void shouldThrowInvalidAgeException()
    {
        assertThrows(InvalidAgeException.class,() -> recruitment.scrutinizeAge(34));
    }

}