package com.ford.nov11.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HashMapSampleTest {

    HashMapSample hmSample;
    TreeMapSample tmSample;
    @BeforeEach
    void setUp() {

        hmSample = new HashMapSample();
        tmSample = new TreeMapSample();
    }

    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldDisplayHashMapObjects()
    {
        assertTrue(hmSample.fetchHashMapObjectsThruKeySet());
    }

    @Test
    public void shouldDisplayHashMapObjectsThryKeySet()
    {
        assertTrue(tmSample.fetchTreeMapObjectsThruEntrySet());
    }
}