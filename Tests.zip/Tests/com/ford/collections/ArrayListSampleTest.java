package com.ford.collections;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArrayListSampleTest {
    ArrayListSample arrayListSample;
    LinkedListSample linkedListSample;
    @BeforeEach
    void setUp() {
        arrayListSample = new ArrayListSample();
        linkedListSample = new LinkedListSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldReturnList()
    {
        //given
        boolean flag = false;
        //when
        flag = arrayListSample.fetchEmployees();
        //then
        assertEquals(true,flag);

    }
    @Test
    public void shouldReturnLinkedList()
    {
        //given
        boolean flag = false;
        //when
        flag = linkedListSample.fetchLinkedListObjects();
        //then
        assertEquals(true,flag);
    }
}