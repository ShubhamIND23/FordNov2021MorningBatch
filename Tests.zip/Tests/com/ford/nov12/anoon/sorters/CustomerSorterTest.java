package com.ford.nov12.anoon.sorters;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class CustomerSorterTest {

    CustomerSorter customerSorter;
    ArrayList <Customer> expectedSortedCustomersById;
    ArrayList <Customer> expectedSortedCustomersByName;
    ArrayList <Customer> expectedSortedCustomersByPurchValue;
    @BeforeEach
    void setUp() {
        customerSorter = new CustomerSorter();
        expectedSortedCustomersById = new ArrayList<Customer>();
        expectedSortedCustomersByName = new ArrayList<Customer>();
        expectedSortedCustomersByPurchValue = new ArrayList<Customer>();

        //Sorted w.r.t ID
        Customer c1 = new Customer("C001","Ramesh","Chennai","9849999498",1000.0f,"Product1");
        expectedSortedCustomersById.add(c1);
        expectedSortedCustomersById.add(new Customer("C002","Mahesh","Bangalore","9849934498",2000.0f,"Product2"));
        expectedSortedCustomersById.add(new Customer("C003","Sumanth","Hyderabad","9845699498",3000.0f,"Product3"));
        expectedSortedCustomersById.add(new Customer("C004","Kiran","Faridabad","9849996798",4000.0f,"Product4"));
        expectedSortedCustomersById.add(new Customer("C005","Rakesh","Ernakulam","9834999498",5000.0f,"Product5"));

       //Sorted w.r.t Name
        expectedSortedCustomersByName.add(new Customer("C004","Kiran","Faridabad","9849996798",4000.0f,"Product4"));
        expectedSortedCustomersByName.add(new Customer("C002","Mahesh","Bangalore","9849934498",2000.0f,"Product2"));
        expectedSortedCustomersByName.add(new Customer("C005","Rakesh","Ernakulam","9834999498",5000.0f,"Product5"));
        Customer c2 = new Customer("C001","Ramesh","Chennai","9849999498",1000.0f,"Product1");
        expectedSortedCustomersByName.add(c2);
        expectedSortedCustomersByName.add(new Customer("C003","Sumanth","Hyderabad","9845699498",3000.0f,"Product3"));
        //Sorted w.r.t PurchaseValue

        Customer c3 = new Customer("C001","Ramesh","Chennai","9849999498",1000.0f,"Product1");
        expectedSortedCustomersByPurchValue.add(c3);
        expectedSortedCustomersByPurchValue.add(new Customer("C002","Mahesh","Bangalore","9849934498",2000.0f,"Product2"));
        expectedSortedCustomersByPurchValue.add(new Customer("C003","Sumanth","Hyderabad","9845699498",3000.0f,"Product3"));
        expectedSortedCustomersByPurchValue.add(new Customer("C004","Kiran","Faridabad","9849996798",4000.0f,"Product4"));
        expectedSortedCustomersByPurchValue.add(new Customer("C005","Rakesh","Ernakulam","9834999498",5000.0f,"Product5"));


    }

    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldSortCustomersById()
    {
        //Given : as in SetUp
        //When
        ArrayList <Customer> actualCustomersSortedById = customerSorter.sortCustomersById();
        //Then
        assertEquals(expectedSortedCustomersById,actualCustomersSortedById);
    }
    @Test
    public void shouldSortCustomersByName()
    {
        //Given : as in SetUp
        //When
        ArrayList <Customer> actualCustomersSortedByName = customerSorter.sortCustomersByName();
        //Then
        assertEquals(expectedSortedCustomersByName,actualCustomersSortedByName);

    }
    @Test
    public void shouldSortCustomersByPurchaseValue()
    {
            //Given : as in setUp
            //When
            ArrayList <Customer> actualCustomersSortedByPurchValue = customerSorter.sortCustomersByPurchValue();
            //Then
            assertEquals(expectedSortedCustomersByPurchValue,actualCustomersSortedByPurchValue);
    }
}