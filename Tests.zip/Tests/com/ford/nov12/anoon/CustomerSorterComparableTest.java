package com.ford.nov12.anoon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class CustomerSorterComparableTest {

    CustomerSorterComparable csComparable;
    ArrayList <Customer> expectedSortedCustomersById;
    ArrayList <Customer> expectedSortedCustomersByAddress;
    ArrayList <Customer> expectedSortedCustomersByPurchValue;
    @BeforeEach
    void setUp() {
        csComparable = new CustomerSorterComparable();
        expectedSortedCustomersById = new ArrayList<Customer>();
        expectedSortedCustomersByAddress = new ArrayList<Customer>();
        expectedSortedCustomersByPurchValue = new ArrayList<Customer>();

        //Sorted wrt ID
        Customer c1 = new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1");
        expectedSortedCustomersById.add(c1);
        expectedSortedCustomersById.add(new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2"));
        expectedSortedCustomersById.add(new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3"));
        expectedSortedCustomersById.add(new Customer("C004","Kiran","Malleswaram","9849996798",4000.0f,"Product4"));
        expectedSortedCustomersById.add(new Customer("C005","Rakesh","Vijayanagar","9834999498",5000.0f,"Product5"));
        //Sorted wrt Address

        expectedSortedCustomersByAddress.add(new Customer("C002","Mahesh","Bangalore","9849934498",2000.0f,"Product2"));
        Customer c2 = new Customer("C001","Ramesh","Chennai","9849999498",1000.0f,"Product1");
        expectedSortedCustomersByAddress.add(c2);
        expectedSortedCustomersByAddress.add(new Customer("C005","Rakesh","Ernakulam","9834999498",5000.0f,"Product5"));
        expectedSortedCustomersByAddress.add(new Customer("C004","Kiran","Faridabad","9849996798",4000.0f,"Product4"));

        expectedSortedCustomersByAddress.add(new Customer("C003","Sumanth","Hyderabad","9845699498",3000.0f,"Product3"));
         //Sorted wrt Purchase Value
        Customer c3 = new Customer("C001","Ramesh","Chennai","9849999498",1000.0f,"Product1");
        expectedSortedCustomersByPurchValue.add(c3);
        expectedSortedCustomersByPurchValue.add(new Customer("C002","Mahesh","Bangalore","9849934498",2000.0f,"Product2"));
        expectedSortedCustomersByPurchValue.add(new Customer("C003","Sumanth","Hyderabad","9845699498",3000.0f,"Product3"));
        expectedSortedCustomersByPurchValue.add(new Customer("C004","Kiran","Faridabad","9849996798",4000.0f,"Product4"));

        expectedSortedCustomersByPurchValue.add(new Customer("C005","Rakesh","Ernakulam","9834999498",5000.0f,"Product5"));




    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldSortCustomersById()
    {
        //Given : as in SetUp
        //When
        ArrayList <Customer> actualSortedCustomersById = csComparable.getCustomersSortedById();
        //Then
        assertEquals(expectedSortedCustomersById,actualSortedCustomersById);
    }
    @Test
    public void shouldSortCustomersByAddress()
    {
        //Given : as in SetUp
        //When
        ArrayList <Customer> actualSortedCustomersByAddress = csComparable.getCustomersSortedByAddress();
        //Then
        assertEquals(expectedSortedCustomersByAddress,actualSortedCustomersByAddress);
    }
    @Test
    public void shouldSortCustomersByPurchValue()
    {
        //Given : as in SetUp
        //When
        ArrayList <Customer> actualSortedCustomersByPurchValue = csComparable.getCustomersSortedByPurchaseValue();
        //Then
        assertEquals(expectedSortedCustomersByPurchValue,actualSortedCustomersByPurchValue);
    }
}