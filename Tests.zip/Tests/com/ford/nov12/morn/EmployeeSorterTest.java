package com.ford.nov12.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeSorterTest {

    ArrayList <Employee> idSortedEmployees;
    ArrayList <Employee> nameSortedEmployees;
    ArrayList <Employee> salarySortedEmployees;
    EmployeeSorter employeeSorter;
    @BeforeEach
    void setUp() {
        employeeSorter = new EmployeeSorter();
        idSortedEmployees = new ArrayList<Employee>();
        nameSortedEmployees = new ArrayList<Employee>();
        salarySortedEmployees = new ArrayList<Employee>();

        idSortedEmployees.add(new Employee("E001","Amarnath","Faridabad","9499499494",10000));
        idSortedEmployees.add(new Employee("E002","Babu","Ahmedabad","9499499494",12000));
        idSortedEmployees.add(new Employee("E003","Chandu","Coimbatore","9499499494",14000));

        nameSortedEmployees.add(new Employee("E001","Amarnath","Faridabad","9499499494",10000));
        nameSortedEmployees.add(new Employee("E003","Babu","Coimbatore","9499499494",14000));
        nameSortedEmployees.add(new Employee("E002","Chandu","Ahmedabad","9499499494",12000));

        salarySortedEmployees.add(new Employee("E001","Amarnath","Faridabad","9499499494",10000));
        salarySortedEmployees.add(new Employee("E002","Chandu","Ahmedabad","9499499494",12000));
        salarySortedEmployees.add(new Employee("E003","Babu","Coimbatore","9499499494",14000));



    }
    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldSortEmployeesById()
    {
        //Given: as in SetUp
        //when
        ArrayList <Employee> actualIdSortedEmployees = employeeSorter.getSortedEmployeesById();
        //Then
        assertEquals(idSortedEmployees,actualIdSortedEmployees);
    }

    @Test
    public void shouldSortEmployeesByName()
    {
        //Given : as In SetUp
        //When
        ArrayList <Employee> actualNameSortedEmployees = employeeSorter.getSortedEmployeesByName();
        //Then
        assertEquals(nameSortedEmployees,actualNameSortedEmployees);

    }

    @Test
    public void shouldSortEmployeesBySalary()
    {
        //Given : as In SetUp
        //When
        ArrayList <Employee> actualSalarySortedEmployees = employeeSorter.getSortedEmployeesBySalary();
        //Then
        assertEquals(salarySortedEmployees,actualSalarySortedEmployees);
    }
}