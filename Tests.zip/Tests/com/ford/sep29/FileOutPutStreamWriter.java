package com.ford.sep29;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class FileOutPutStreamWriter {

    FileOutputStream fos;
    byte[] myBytes = new byte[100];
    boolean flag = false;
    String str1 = new String("This Data Goes To File");
    public boolean writeToFileStream()
    {
             myBytes = str1.getBytes();
            File file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\FordFiles\\Customer.txt");
            try {
                fos = new FileOutputStream(file1);
                fos.write(myBytes);
                fos.flush();
                fos.close();
                flag = true;
                System.out.println("Written Data into Binary Stream Based file successfully..");
            }
            catch(FileNotFoundException fnfe)
            {
                flag = false;
                fnfe.printStackTrace();
            }
            catch(IOException ioe)
            {
                flag = false;
                ioe.printStackTrace();
            }
            return flag;

    }
}
