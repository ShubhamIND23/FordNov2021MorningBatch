package com.ford.sep29;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FileOutPutStreamWriterTest {

    FileOutPutStreamWriter fops;
    @BeforeEach
    void setUp() {
        fops = new FileOutPutStreamWriter();

    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldWriteToBinaryFile()
    {
        //when
        boolean result = fops.writeToFileStream();
        assertEquals(true,result);
    }
}